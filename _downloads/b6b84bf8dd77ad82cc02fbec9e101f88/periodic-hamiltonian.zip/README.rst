Periodic Hamiltonian Learning
=============================

