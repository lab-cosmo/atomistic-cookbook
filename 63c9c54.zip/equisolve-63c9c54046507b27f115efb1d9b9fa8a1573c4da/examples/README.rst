Equisolve Examples
==================

This folder consists of introductory examples.
