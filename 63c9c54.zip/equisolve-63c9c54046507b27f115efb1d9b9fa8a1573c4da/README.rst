equisolve
=========

|test| |docs|

A package tasked with taking metatensor objects and computing machine learning
models using them.

.. warning::

    **equisolve is still as the proof of concept stage. You should not use it for
    anything important.**

For details, tutorials, and examples, please have a look at our `documentation`_.

.. _`documentation`: https://lab-cosmo.github.io/equisolve/latest/

.. |test| image:: https://github.com/lab-cosmo/equisolve/actions/workflows/tests.yml/badge.svg
   :alt: Github Actions Tests Job Status
   :target: https://github.com/lab-cosmo/equisolve/actions/workflows/tests.yml

.. |docs| image:: https://img.shields.io/badge/documentation-latest-sucess
   :alt: Documentation
   :target: https://lab-cosmo.github.io/equisolve/latest/
