.. _userdoc-how-to:

How-to guides
=============

This section list recipes how to the various classes and functions 
of ``equisolve`` to build models. For details on the 
API specification of the functions take a look at the 
:ref:`userdoc-reference` section.

.. toctree::
    :maxdepth: 1

    ../examples/linear-model
