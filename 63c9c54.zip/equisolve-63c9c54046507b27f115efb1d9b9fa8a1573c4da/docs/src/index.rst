Overview of Equisolve's Documentation
=====================================

Welcome to the documentation of `equisolve`. Use the sidebar menu
to navigate through the sections. If you are looking for the
specifications of the classes and functions take a look at the
:ref:`userdoc-reference`. Detailed recipes are listed inside the 
:ref:`userdoc-how-to`.

.. toctree::
   :hidden:

   how-to/index
   reference/index
