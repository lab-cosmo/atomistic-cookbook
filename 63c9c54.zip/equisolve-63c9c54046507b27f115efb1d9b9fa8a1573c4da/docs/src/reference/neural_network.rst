Neural Network
==============

.. automodule:: equisolve.nn
    :members:
