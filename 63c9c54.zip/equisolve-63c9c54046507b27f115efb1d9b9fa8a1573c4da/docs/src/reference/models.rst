Regression models
=================

.. automodule:: equisolve.numpy.models
    :members:
