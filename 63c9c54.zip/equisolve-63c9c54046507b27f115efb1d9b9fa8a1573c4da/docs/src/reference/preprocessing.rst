Preprocessing data
==================

.. automodule:: equisolve.numpy.preprocessing
    :members:
