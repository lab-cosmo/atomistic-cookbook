``GreedySelector``
==================

.. autoclass:: equisolve.numpy._selection.GreedySelector
    :members:
