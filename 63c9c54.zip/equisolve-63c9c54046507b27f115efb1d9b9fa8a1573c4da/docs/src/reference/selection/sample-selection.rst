Sample selection
================

.. automodule:: equisolve.numpy.sample_selection
    :members:
    :show-inheritance:
