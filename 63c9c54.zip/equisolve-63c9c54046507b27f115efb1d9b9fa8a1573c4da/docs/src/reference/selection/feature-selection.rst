Feature selection
=================

.. automodule:: equisolve.numpy.feature_selection
    :members:
    :show-inheritance:
