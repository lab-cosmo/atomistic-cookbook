Splitting Equistore TensorMaps
==============================

.. automodule:: equisolve.utils.split_data
    :members:
    :show-inheritance:
