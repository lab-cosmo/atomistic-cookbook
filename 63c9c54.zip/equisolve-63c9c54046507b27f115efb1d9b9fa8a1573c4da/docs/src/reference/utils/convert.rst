Convert
=======

.. automodule:: equisolve.utils.convert
    :members:
    :show-inheritance:
