Metrics and scoring
===================

.. automodule:: equisolve.utils.metrics
    :members:
    :show-inheritance:
