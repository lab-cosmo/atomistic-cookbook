Utility functions
=================

Helper classes and functions to build models.

.. toctree::
    convert
    metrics
    split_data
