# Path integral metadynamics

Path integrals simulatins are able to describe the quantum thermodynamics
of distinguishable particles at finite temperature, and are the most accurate
approach to describe the behavior of light nuclei (e.g. hydrogen) at 
room temperature and above. 

They can be combined with metadynamics to accelerate the sampling of rare
events, and compute a "quantum free energies" that reflect (in an approximate
way) the effect of zero-point energy and tunneling on reaction rates. 

## Free-energy of the Zundel cation

This lecture provide a hands-on interactive tutorial (that you can also 
download and run locally) that uses the [i-PI code](http://ipi-code.org)
to perform path-integral simulations for the Zundel cation, a protonated
water dimer. PLUMED is used to compute appropriate collective variables,
using an input as follows

```plumed
# default units are LENGTH=nm ENERGY=kJ/mol TIME=ps
doo: DISTANCE ATOMS=1,2 
co1: DISTANCES GROUPA=1 GROUPB=3-7 LESS_THAN={RATIONAL R_0=0.14}
co2: DISTANCES GROUPA=2 GROUPB=3-7 LESS_THAN={RATIONAL R_0=0.14}
dc: COMBINE ARG=co1.lessthan,co2.lessthan COEFFICIENTS=1,-1 PERIODIC=NO
mtd:   METAD ARG=doo,dc PACE=10 SIGMA=0.005,0.05 HEIGHT=4 FILE=HILLS-pimd BIASFACTOR=10 TEMP=300
uwall: UPPER_WALLS ARG=doo AT=0.4 KAPPA=250

PRINT ARG=doo,co1.*,co2.*,dc,mtd.*,uwall.* STRIDE=10 FILE=COLVAR-pimd
FLUSH STRIDE=1
```

Depending on your previous experience, you may want to follow the 
lessons on metadynamics, and the external tutorial on path integral
simulations.


```mermaid
flowchart LR
A[Basic plumed syntax] ==> B[Metadynamics]
B ==> D[Path integral metadynamics]
C[Introduction to path integrals] ==> D
click A "basics" "Follow this lecture for an introduction to PLUMED and enhanced sampling"
click B "metad" "Follow this lecture if you have never heard of metadynamics before"
click C "pathintegrals" "An interactive tutorial on path integral simulations and how to perform them using i-PI"
click D "pimetad" "The main tutorial: combine i-PI and PLUMED to compute free energies including quantum nuclear effects"
```

