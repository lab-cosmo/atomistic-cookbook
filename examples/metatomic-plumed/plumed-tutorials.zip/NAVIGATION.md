# Defining custom machine learning CV with metatomic

[Metatomic](https://docs.metatensor.org/metatomic/) is a library to use
arbitrary machine learning models together with arbitrary simulation tools.
Here we show how to use the interface between metatomic and plumed to define
fully custom collective variables (CV). These CV can be defined using typical
machine learning tools, but any Python function based on PyTorch will also work,
allowing to define new CV extremely easily.

Through the use of PyTorch, you can focus on defining the CV itself, and
automatically get its gradients. You can also execute the code computing your CV
on GPUs and other accelerators.

Other tools are able to interact with CV defined as metatomic models, most
notably [chemiscope](https://chemiscope.org). You can therefore visualize how
complex CV act on representative structures before even starting a simulation,
and improve the Cv interactively.

## Free-energy surface of LJ38 cluster

The cluster of 38 atoms interacting through a Lennard-Jones potential is an
interesting benchmark system for collective variables, because its global
minimum energy structure is a truncated octahedron with `O_h` symmetry. The
potential energy surface also has a multi-funnel landscape, meaning the system
can easily get trapped in other local minima.

This tutorial contains a hands-on interactive tutorial (that you can also
download and run locally) that defines two different collective variables to
drive metadynamics for this system. The first CV is based on the histogram of
coordination number, and the second one uses a machine learning representation
(the SOAP spherical expansion) as a basis to define Steinhardt oder
parameters-like CVs.


```plumed
soap: METATOMIC ...
    MODEL=soap-cv.pt
    EXTENSIONS_DIRECTORY=./extensions/
    SPECIES1=1-38
    SPECIES_TO_TYPES=18
...

histogram: METATOMIC ...
    MODEL=histo-cv.pt

    SPECIES1=1-38
    SPECIES_TO_TYPES=18
...

cv1: SELECT_COMPONENTS ARG=histogram COMPONENTS=1
cv2: SELECT_COMPONENTS ARG=histogram COMPONENTS=2

mtd: METAD ...
    ARG=cv1,cv2
    HEIGHT=0.04
    PACE=30
    SIGMA=1.0,0.5
    GRID_MIN=0,0
    GRID_MAX=30,20
    GRID_BIN=300,200
    BIASFACTOR=40
    FILE=HILLS
    TEMP=19.3
...
```

Depending on your previous experience, you may want to follow the lessons on
metadynamics first.


```mermaid
flowchart TD
A[Basic plumed syntax] ==> B[Metadynamics]
B ==> C([Defining and using custom CVs with metatomic])
subgraph D[Reference documentation]
    E[LAMMPS]
    F[i-PI]
    G[metatomic]
end
D -..-> C


click A "plumed" "Follow this lecture for an introduction to PLUMED and enhanced sampling"
click B "metadynamics" "Follow this lecture if you have never heard of metadynamics before"
click C "metatomic-plumed" "An interactive tutorial defining custom CV with metatomic and using them to run metadynamics in both i-PI and LAMMPS"
click E "lammps-plumed" "More information about the interface between LAMMPS and PLUMED"
click F "ipi-plumed" "More information about the interface between i-PI and PLUMED"
click G "metatomic" "More information about metatomic"
```
